created by sqlmapped
Netlas dorks
https://github.com/netlas-io/netlas-dorks
https://github.com/netlas-io/netlas-cookbook


Github dorks
https://github.com/techgaun/github-dorks
https://github.com/jcesarstef/ghhdb-Github-Hacking-Database
https://github.com/H4CK3RT3CH/github-dorks
https://github.com/Vaidik-pandya/Github_recon_dorks/blob/main/gitdork.txt (for finding files)

Many dorks for Github can also be used when searching other code hosting services (Bitbucket, Gitlab, Codeberg etc). You can use the special Google Custom Search Engine to search 20 code hosting services at a time https://cipher387.github.io/code_repository_google_custom_search_engines/


Shodan dorks
https://github.com/blaCCkHatHacEEkr/PENTESTING-BIBLE/blob/master/1-part-100-article/google/Shodan%20Queries.txt
https://github.com/humblelad/Shodan-Dorks
https://github.com/AustrianEnergyCERT/ICS_IoT_Shodan_Dorks
https://github.com/lothos612/shodan
https://github.com/jakejarvis/awesome-shodan-queries
https://github.com/IFLinfosec/shodan-dorks
https://www.osintme.com/index.php/2021/01/16/ultimate-osint-with-shodan-100-great-shodan-queries/


Censys dorks
https://github.com/thehappydinoa/awesome-censys-queries

Virus Total dorks
https://github.com/Neo23x0/vti-dorks


Binary Edge + Shodan + Google
https://github.com/iGotRootSRC/Dorkers


DuckDuckGo dorks
https://github.com/d34dfr4m3/goDuck


Google, Bing, Ecosia, Yahoo or Yandex
https://github.com/Zarcolio/sitedorks


Google dorks
https://github.com/BullsEye0/google_dork_list
https://github.com/sushiwushi/bug-bounty-dorks
https://github.com/rootac355/SQL-injection-dorks-list
https://github.com/unexpectedBy/SQLi-Dork-Repository
https://github.com/thomasdesr/Google-dorks
https://github.com/arimogi/Google-Dorks
https://github.com/aleedhillon/7000-Google-Dork-List


Onion dorks
Universal for Google, Bing etc
Dorks for searching .onion sites saved in oniline proxies services https://github.com/cipher387/Dorks-collections-list/blob/main/onion.txt

CCTV dorks
Universal for Google, Bing etc
Dorks for search CCTV cams admin panels https://github.com/cipher387/Dorks-collections-list/blob/main/cctv.txt
Camera dorks from @tru_1veresk https://github.com/iveresk/camera_dorks/blob/main/dorks.json
Google Dorks of Live Webcams, CCTV etc. (from d4msec) https://d4msec.wordpress.com/2015/09/05/google-dorks-of-live-webcams-cctv-etc-google-unsecured-ip-cameras/

Backlink dorks
(SEO Terminology) Universal for Google, Bing etc
List https://github.com/alfazzafashion/Backlink-dorks
Explanation https://www.techywebtech.com/2021/08/backlink-dorks.html
1150 dorks for forum hunting https://www.blackhatworld.com/seo/get-backlinks-yourself-1150-dorks-for-forum-hunting.380843/

Token dorks
Universal for Google, Bing etc
Discord Bots Tokens https://github.com/traumatism/get-discord-bots-tokens-with-google

Hidden files dorks
Universal for Google, Bing etc
https://github.com/0xAbbarhSF/Info-Sec-Dork-List/blob/main/hidden_files_dork.txt

Admin panel dorks
Universal for Google, Bing etc
https://github.com/cyberm0n/admin-panel-dorks/blob/main/dorks.txt

SQL injection dorks
Universal for Google, Bing etc
SQL injection dorks for goverment sites https://github.com/readloud/Google-Hacking-Database-GHDB/blob/main/sql_gov_dorks.txt
SQL injection dorks 2019 https://github.com/readloud/Google-Hacking-Database-GHDB/blob/main/sqli_dork_2019.txt

Linkedin dorks (Google X-Ray search for Linkedin)
Universal for Google, Bing etc
Linkedin X-Ray search queries and tools https://github.com/krlabs/linkedin-dorks

Carding dorks
Universal for Google, Bing etc
1170 carding dorks https://pastebin.com/GYXLqgU0
17K carding dorks 2019 https://pastebin.com/fgdZxy74

Gaming dorks
Universal for Google, Bing etc
7K Gaming Dorks From My Shop https://pastebin.com/ajuixpY2
Minecraft https://pastebin.com/ssNgdTkC Fortnite https://github.com/ProjectZeroDays/Fortnite-Google-Dorks/blob/main/Fornite%20Google%20Dorks

Shopping dorks
Universal for Google, Bing etc
10k Amazon dorks https://pastebin.com/1HrmzFre
820 shopping Dorks for SQLi https://pastebin.com/1kED1FDX

Cryptocurrency dorks
15K dorks to find vulnerable pages related to cryptocurrency exchanges, cryptocurrency payments, etc. https://www.scribd.com/document/384770530/15k-Btc-Dorks

18K Bitcoin and other cryptocurency related dorks https://pdfcoffee.com/18k-bitcoin-dorks-list--3-pdf-free.html


Bug Bounty Dorks
Universal for Google, Bing etc
https://github.com/hackingbharat/bug-bounty-dorks-archive/blob/main/bbdorks
https://github.com/Vinod-1122/bug-bounty-dorks/blob/main/Dorks.txt

GIT files Dorks
Universal for Google, Bing etc
https://github.com/Proviesec/google-dorks/blob/main/google-dorks-for-git-files.txt

Log files Dorks
Universal for Google, Bing etc
https://github.com/Proviesec/google-dorks/blob/main/google-dorks-best-log.txt

CMS Dorks
Universal for Google, Bing etc
Wordpress https://pastebin.com/A9dsmgHQ
Magento https://pastebin.com/k75Y2QhF
Joomla https://pastebin.com/vVQFTzVC

Cloud instance dorks
Universal for Google, Bing etc
Amazon AWS https://github.com/cipher387/Dorks-collections-list/blob/main/aws.txt
https://github.com/Proviesec/google-dorks/blob/main/google-dorks-for-finding-aws-s3.txt Google Cloud https://github.com/cipher387/Dorks-collections-list/blob/main/googslecloud.txt Microsoft Azure https://github.com/cipher387/Dorks-collections-list/blob/main/azure.txt

Dorks for sites based by wiki engines
Universal for Google, Bing etc
"Wiki" dorks https://github.com/Proviesec/google-dorks/blob/main/google-dorks-for-wikipedia.txt

Awstats dorks
Universal for Google, Bing etc
"Stats" dorks https://github.com/Proviesec/google-dorks/blob/main/google-dorks-for-stats.txt

Movie dorks
Dorks for finding direct links to movies https://github.com/cipher387/Dorks-collections-list/blob/main/movie.txt

Dorks from realDumbleDork posts
https://github.com/cipher387/Dorks-collections-list/blob/main/realDumbleDork_twitter.txt


Tools to automate the work with dorks
Fast Google Dorks Scan https://github.com/IvanGlinkin/Fast-Google-Dorks-Scan
PyDork https://github.com/blacknon/pydork
0xDork https://github.com/rlyonheart/0xdork
SDorker https://github.com/TheSpeedX/SDorker
ASHOK (osint swiss knife) https://github.com/ankitdobhal/Ashok
Padago (Automate Google Hacking Database scraping and searching) https://github.com/opsdisk/pagodo
Katana (Python tool that automates Google Hacking/Dorking and supports Tor) https://github.com/TebbaaX/Katana
GO Dork (fast google search result scanner) https://github.com/dwisiswant0/go-dork
Snitch https://github.com/Smaash/snitch
Dorks Eye https://github.com/BullsEye0/dorks-eye
SQLI Dorks generator https://github.com/Zold1/sqli-dorks-generator
DSH - Discord Server Hunter https://github.com/falkensmz/dsh
Dork hunter https://github.com/six2dez/dorks_hunter

Browser extenstions
Google Dork Builder Firefox Add-on https://addons.mozilla.org/ru/firefox/addon/google-dork-builder/

Online tools to work with dorks
Dorksearch https://dorksearch.com/
FilePhish https://cartographia.github.io/FilePhish/
BugBounty Helper https://dorks.faisalahmed.me
Google Hacking tool from Pentest Tools https://pentest-tools.com/information-gathering/google-hacking
Dork Genius (AI dorks generator) https://dorkgenius.com
Google Bug Bounty Dorks Generator https://taksec.github.io/google-dorks-bug-bounty/
AI Search Whisper https://google.digitaldigging.org/index2.html DorkMe https://www.dorkme.com/ (paid tool for working with search engines API) Google Dorks for Bug Bounty https://taksec.github.io/google-dorks-bug-bounty/ Dorki https://dorki.io/